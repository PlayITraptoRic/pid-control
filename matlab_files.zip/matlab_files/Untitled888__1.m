clear all
clc
A=[0.9900 -0.4930 -0.0260 -0.1033 -0.0769
    0.0162 0.9907 0.7521 -0.2880 0.5406 
    -0.0005 -0.0006 0.6030 0.7346 0.1834
    -0.0002 0.0012  -0.3761 0.0323 0.9153 
    -0.0001 0.0003 0.1408 -0.5039 -0.1200];

B=[-0.5783 0.2534 -0.0918 -0.1306 0.0198]';

D=[-0.3773 -0.5658 0.5351 -0.3387 0.3175];

nx=size(A,1);

h=1;
T=0:h:500;
N=length(T);
zeta=6;
eta=1/(2*pi);

Y=zeros(N,1);

% Find the exact paramters (i.e. no noise)
[Ac,Bc,Dc]=d2cm(A,B,D,0,1,'zoh');
[b,a]=ss2tf(Ac,Bc,Dc,0);
hp0=tf(b,a);
Tst=0:h:30;
Yst=step(hp0,Tst);
[R1,calL]=prc(Yst,Tst); %without noise
K0=zeta*R1/calL; tau0=eta*calL; 
cb=2.12; gamm=2.12; delta=2.3;
[Kp0,Td0]=pd_tun_maxdelay(K0,tau0,delta,cb,1);
Ti0=gamm*Td0;
dv=0.03; dw=0.03; 

randn('seed',1)

% Prosess- og male-stoy
v=randn(N,nx)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
KpTdh=Kp0*Td0/h;
KpTih=Kp0*h/Ti0;
ym=36; um=1.5;
x=zeros(nx,1); %x=[-372.6949;-109.2233;-28.8630;-2.5179;-0.2912]; 
r=36; z=0; y_old=35;
for k=1:N
y=D*x+w(k);
y=ym+y;
e=r-y;
u=Kp0*e-KpTdh*(y-y_old)+z;
u=u;
z=z+KpTih*e;
   
if k>250
   u=u+1.5; 
   %r=10;
end

Y(k)=y; R(k)=r; U(k)=u;
x=A*x+B*(u-um)+v(k,:)';

end %k=N

figure(1)
subplot(211),plot(T,Y,T,R,'r--'),title('$y$: Bottom-riser pressure','Interpreter','latex'),ylabel('$y$','Interpreter','latex'),grid
subplot(212),plot(T,U),title('$u$: Top side choke','Interpreter','latex'),grid,ylabel('$u$','Interpreter','latex'),xlabel('Time, $t$','Interpreter','latex')

