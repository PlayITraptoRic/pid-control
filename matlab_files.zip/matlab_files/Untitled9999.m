clear all
clc
     
A=[0.9900 -0.4930 -0.0260 -0.1033 -0.0769
    0.0162 0.9907 0.7521 -0.2880 0.5406 
    -0.0005 -0.0006 0.6030 0.7346 0.1834
    -0.0002 0.0012  -0.3761 0.0323 0.9153 
    -0.0001 0.0003 0.1408 -0.5039 -0.1200];

B=[-0.5783 0.2534 -0.0918 -0.1306 0.0198]';

D=[-0.3773 -0.5658 0.5351 -0.3387 0.3175];

nx=size(A,1);

M=200;
N=2000;

Tmin=10;
Tmax=100;

n=5;
L=10;
J=5;
zeta=1; eta=1/(2*pi);
U=prbs1(N,Tmin,Tmax);
Y=zeros(N,1);
randn('seed',0)
for j=1:M

%randn('seed',0)
%U=prbs1(N,Tmin,Tmax);
dv=0.2; dw=0.1;
% Prosess- og m?le-st?y
v=randn(N,nx)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
 
x=zeros(nx,1);
for k=1:N

y=D*x+w(k);

u=U(k);
Y(k)=y;

x=A*x+B*u+v(k,:)';

end

[Adsr,Bdsr,Ddsr,Edsr,~,~,x0]=dsr(Y,U,L,0,J,1,n);
u=1;
Tst=0:1:N; x=x0;
for i=1:N
y=Ddsr*x;

Yst(i)=y;

x=Adsr*x+Bdsr*u;

end

%h=Tst(2)-Tst(1); Aa=diff(Yst)/h; 
h=1; Aa=diff(Yst)/h; 

if Yst(end)<0
 [R,i]=min(Aa);
else 
 [R,i]=max(Aa);
end

t1=i;
y1=Yst(i); Ll=t1-y1/R;
K=zeta*R/Ll; tau=eta*Ll; 
Kk(j)=K; tauu(j)=tau;
end

x=zeros(nx,1);
for i=1:N
y=D*x;

Yst(i)=y;

x=A*x+B*u;

end

h=1; Aa=diff(Yst)/h; 

if Yst(end)<0
 [R,i]=min(Aa);
else 
 [R,i]=max(Aa);
end

t1=i;
y1=Yst(i); Ll=t1-y1/R;
K0=zeta*R/Ll; tau0=eta*Ll; 


figure(1)
subplot(211),plot(1:M,Kk,1:M,mean(Kk)*ones(M,1),1:M,K0*ones(M,1)),ylabel('Gain Acceleration, K'),legend('est K','mean K','exact K'),title('Monte Carlo Simulations')
subplot(212),plot(1:M,tauu,1:M,mean(tauu)*ones(M,1),1:M,tau0*ones(M,1)),ylabel('Time Delay, \tau'), xlabel('Simulation, j'),legend('est \tau','mean \tau','exact \tau')
s=tf('s');
[Kp,Ti,Td]=delta_prc_pid_tun(Tst,Yst,2.3,2);hc=Kp*(1+1/(Ti*s)+Td*s);
%(1/(hp*hc+1))