clear all
clc
A=[0.9900 -0.4930 -0.0260 -0.1033 -0.0769
    0.0162 0.9907 0.7521 -0.2880 0.5406 
    -0.0005 -0.0006 0.6030 0.7346 0.1834
    -0.0002 0.0012  -0.3761 0.0323 0.9153 
    -0.0001 0.0003 0.1408 -0.5039 -0.1200];

B=[-0.5783 0.2534 -0.0918 -0.1306 0.0198]';

D=[-0.3773 -0.5658 0.5351 -0.3387 0.3175];

nx=size(A,1);

h=0.001;
M=100;
N=1000;

n=3;

zeta=6;
eta=1/(2*pi);

Tmin=5;
Tmax=30;
U=prbs1(N,Tmin,Tmax);
Y=zeros(N,1);

% Find the exact paramters (i.e. no noise)
[Ac,Bc,Dc]=d2cm(A,B,D,0,1,'zoh');
[b,a]=ss2tf(Ac,Bc,Dc,0);
hp0=tf(b,a);
Tst=0:h:30;
Yst=step(hp0,Tst);
[R1,calL]=prc(Yst,Tst); %without noise
K0=zeta*R1/calL; tau0=eta*calL; 
cb=2.12; gamm=2.12; delta=3; J=8;
[Kp0,Td0]=pd_tun_maxdelay(K0,tau0,delta,cb,1);
Ti0=gamm*Td0;
LoL=[5,6,7,8];
dv=0.5; dw=0.5; 
NN=length(LoL);
randn('seed',1)

%V=zeros(N,1); V2=zeros(N,1); V3=zeros(N,1); 
for i=1:NN
    L=LoL(i);
   % J=LoL(i);
    
    % initialize
    sum=0;  sum2=0;
    tauu=zeros(M,1); Kk=zeros(M,1);
    Kpp=zeros(M,1); Tii=zeros(M,1); Tdd=zeros(M,1); 

for j=1:M
% Prosess- og male-stoy
v=randn(N,nx)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
 
x=zeros(nx,1);
for k=1:N

y=D*x+w(k);

u=U(k);
Y(k)=y;

x=A*x+B*u+v(k,:)';

end %k=N

[Adsr,Bdsr,Ddsr]=dsr(Y,U,L,0,J,1,n);

[Ac,Bc,Dc]=d2cm(Adsr,Bdsr,Ddsr,0,1,'zoh');
[b,a]=ss2tf(Ac,Bc,Dc,0);
hp=tf(b,a);
Yst=step(hp,Tst);

[R1,calL]=prc(Yst,Tst);
K=zeta*R1/calL; tau=eta*calL; 

sum=sum+(K-K0)*(K-K0)';
sum2=sum2+(tau-tau0)*(tau-tau0)';

[Kp,Td]=pd_tun_maxdelay(K,tau,delta,cb,1); Ti=gamm*Td;

Kk(j)=K; tauu(j)=tau;
Kpp(j)=Kp; Tii(j)=Ti; Tdd(j)=Td;
end %j=M

V(i)=N/(M-1)*sum;
V2(i)=N/(M-1)*sum2;
V3(i)=V(i)+V2(i);
KkK(:,i)=Kk; tauuU(:,i)=tauu;
KP(:,i)=Kpp; TI(:,i)=Tii; TD(:,i)=Tdd;
end %i=NN

figure(1)
subplot(411),plot(1:M,KkK(:,1),'r-',1:M,K0*ones(M,1),'k-'),ylim([0.3,2]),title('Gain acceleration $K$ parameter estimates','Interpreter','latex'),ylabel('$L=5$','Interpreter','latex'),grid
subplot(412),plot(1:M,KkK(:,2),'r-',1:M,K0*ones(M,1),'k-'),ylim([0.3,2]),ylabel('$L=6$','Interpreter','latex'),grid
subplot(413),plot(1:M,KkK(:,3),'r-',1:M,K0*ones(M,1),'k-'),ylim([0.3,2]),ylabel('$L=7$','Interpreter','latex'),grid
subplot(414),plot(1:M,KkK(:,4),'r-',1:M,K0*ones(M,1),'k-'),ylim([0.3,2]),xlabel('Simulations (Monte Carlo)','Interpreter','latex'),ylabel('$L=8$','Interpreter','latex'),grid

figure(2)
subplot(411),plot(1:M,tauuU(:,1),'r-',1:M,tau0*ones(M,1),'k-'),ylim([0.1,1]),title('Time delay $\tau$ parameter estimates','Interpreter','latex'),ylabel('$L=5$','Interpreter','latex'),grid
subplot(412),plot(1:M,tauuU(:,2),'r-',1:M,tau0*ones(M,1),'k-'),ylim([0.1,1]),ylabel('$L=6$','Interpreter','latex'),grid
subplot(413),plot(1:M,tauuU(:,3),'r-',1:M,tau0*ones(M,1),'k-'),ylim([0.1,1]),ylabel('$L=7$','Interpreter','latex'),grid
subplot(414),plot(1:M,tauuU(:,4),'r-',1:M,tau0*ones(M,1),'k-'),ylim([0.1,1]),xlabel('Simulations (Monte Carlo)','Interpreter','latex'),ylabel('$L=8$','Interpreter','latex'),grid

figure(3)
subplot(311),plot(1:M,KP(:,4),'r-',1:M,Kp0*ones(M,1),'k-'),ylim([0,1.5]),title('Controller parameters $K_p,T_i,T_d$ estimates ($L=8$, $J=12$, $\delta=2.3$)','Interpreter','latex'),ylabel('$K_p$','Interpreter','latex'),grid
subplot(312),plot(1:M,TI(:,4),'r-',1:M,Ti0*ones(M,1),'k-'),ylim([0,12]),ylabel('$T_i$','Interpreter','latex'),grid
subplot(313),plot(1:M,TD(:,4),'r-',1:M,Td0*ones(M,1),'k-'),ylim([0,6]),ylabel('$T_d$','Interpreter','latex'),grid,xlabel('Simulations (Monte Carlo)','Interpreter','latex'),

V(end)
V2(end)
V3(end)