clear all
clc

A=[0.9763 0.0199 0.3263;
    0.0062 0.8818 -0.0907; 
   -0.0024 0.0072 0.9758];

B=[-0.0434;
   0.0234; 
    -0.0100];

D=[0.2664   0.2876 -0.4633];
h=0.01;
   A=[0.9769 0.0124 0.3221;
0.0059 0.8811 0.1076;
-0.0025 0.0079 0.9742];

B=[-0.0032;
-0.0021;
0.0000];

D=[0.2142 -0.4070 -0.1428];
A=[0.9769 0.0124 0.3221;
0.0059 0.8811 0.1076;
-0.0025 0.0079 0.9742];

B=[0.0368;
-0.1505;
0.0167];

 A=[0.9767 0.0124 0.3221;
0.0059 0.8811 0.1076;
-0.0025 0.0079 0.9742];

B=[-74.9;
41.07;
-20];

D=[0.2749 0.2825 -0.476];

M=100;
N=1000;

n=3;
%L=8;
%J=8;

zeta=1;
eta=1/(2*pi);

Tmin=5;
Tmax=30;
U=prbs1(N,Tmin,Tmax);

Y=zeros(N,1);

[Ac,Bc,Dc]=d2cm(A,B,D,0,1,'zoh');
[b,a]=ss2tf(Ac,Bc,Dc,0);
hp0=tf(b,a);
Tst=0:h:30;
Yst=step(hp0,Tst);
[R1,calL]=prc(Yst,Tst); %without noise
K0=zeta*R1/calL; tau0=eta*calL; 
LoL=[3,4,5,6];
dv=0.01; dw=0.01; 
NN=length(LoL);
randn('seed',1)
for i=1:NN
    L=LoL(i);
    J=LoL(i);
sum=0;  
tauu=zeros(M,1); Kk=zeros(M,1);
%randn('seed',1)
for j=1:M
% Prosess- og male-stoy
v=randn(N,nx)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
 
x=zeros(nx,1);
for k=1:N

y=D*x+w(k);

u=U(k);
Y(k)=y;

x=A*x+B*u+v(k,:)';

end

[Adsr,Bdsr,Ddsr,~,x0]=dsr(Y,U,L,0,J,1,n);
[Ac,Bc,Dc]=d2cm(Adsr,Bdsr,Ddsr,0,1,'zoh');
[b,a]=ss2tf(Ac,Bc,Dc,0);
hp=tf(b,a);
Yst=step(hp,Tst);

[R1,calL]=asad(Yst,Tst);
K=zeta*R1/calL; tau=eta*calL; 
Kk(j)=K; tauu(j)=tau;
sum=sum+([K tau]-[K0 tau0])*([K tau]-[K0 tau0])';
end

V_alg=N/(M-1)*sum;
VALG(i)=V_alg;
KkK(:,i)=Kk; tauuU(:,i)=tauu;
end
figure(1)
subplot(411),plot(1:M,KkK(:,1),'r-',1:M,K0*ones(M,1),'k-'),title('Monte Carlo Sim. (Gain accel. K)'),ylabel('L=J=4')
subplot(412),plot(1:M,KkK(:,2),'r-',1:M,K0*ones(M,1),'k-'),ylabel('L=J=6')
subplot(413),plot(1:M,KkK(:,3),'r-',1:M,K0*ones(M,1),'k-'),ylabel('L=J=8')
subplot(414),plot(1:M,KkK(:,4),'r-',1:M,K0*ones(M,1),'k-'),xlabel('Simulations'),ylabel('L=J=16')

figure(2)
subplot(411),plot(1:M,tauuU(:,1),'r-',1:M,tau0*ones(M,1),'k-'),title('Monte Carlo Sim. (time delay. \tau)'),ylabel('L=J=4')
subplot(412),plot(1:M,tauuU(:,2),'r-',1:M,tau0*ones(M,1),'k-'),ylabel('L=J=6')
subplot(413),plot(1:M,tauuU(:,3),'r-',1:M,tau0*ones(M,1),'k-'),ylabel('L=J=8')
subplot(414),plot(1:M,tauuU(:,4),'r-',1:M,tau0*ones(M,1),'k-'),xlabel('Simulations'),ylabel('L=J=16')
