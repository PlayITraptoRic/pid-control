% ode45solver.m                                     %
%---------------------------------------------------%
% Investiagation of different control strategies on %
% a simplified non-linear model for a pipeline-riser% 
% process by Di Meglio.                             %  
%---------------------------------------------------%
% Developed by C.D in Octave.

clear all;
clc

h = 0.1; %sampling time [s]
t0 = 0; %starting time
t1 = 300; %ending time [s]
T = (0:h:t1); %time vector
N = length(T); % no. samples

% input experiment
Uexp=(prbs1(N,40,250)*pi/2)+0;  
Uexp=(prbs1(N,1,20)*10)+100;  

%dv=0.002; dw=0.006;
dv=0; dw=0; 
% storing matrices
X=zeros(N,12); Y=zeros(N,1); U=zeros(N,1);

v=randn(N,12)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
 
% settings for mfdelta pi pid tuning
L=3; J=5; n=2; delta=2.3; zeta=1;
bprbs=1; m=1;

% loop
x=zeros(12,1); x(1)=1; y_old=0;
z=0; r=pi/15; u=0.2;
for k = 1:N
    k
    tk = T(k);
    y=x(1);
    
    if(bprbs==0)
        
        if k<1200
           u=0;
        else
           e=r-y;
           u=Kp*e-KpTdh*(y-y_old)+z;
           z=z+KpTih*e;
      end
    elseif(bprbs==1)
      % updating the control signal

      if k<500
          u=100;
      elseif k<1000
             u=Uexp(k); 
      else 
          
          Yid=Y(500:end); Uid=U(500:end);
          %  [Kp,Ti,Td]=mfdelta_pi_pid_tun...
       %   (h,Yid,Uid,bpid,bmean,L,J,n,delta,zeta);
[Kp,Ti,Td] =pidtun(Yid,Uid,h,m,L,J,n,delta);
          KpTdh=Kp*Td/h;
           KpTih=Kp*h/Ti; 
           bprbs=0;
      end
     
    end
    % store last value
    y_old=y; 
    u_old=u;
    
   %if u>pi/2  
   %    u=pi/2;
        
   % elseif u<-pi
    %    u=-pi;
    %end
    
   if tk>25
          r=+pi/16;
      % u=u+1;
   end
  
    % store data 
    Y(k)=y; X(k,:) = x'; U(k)=u; R(k)=r;
    
    % discretise the model
    %[Time,sol] = ode45(@DSRV,[tk tk+h],x',[],u);
  [Time,sol] = ode45(@npsauv,[tk tk+h],x',[],u);
    % update model with last element
    x = sol(end,:)'+v(k)';
end

figure(1)
subplot(211),plot(T,Y*180/pi,T,R*180/pi,'r--'),title('$y$: Angle of attack [deg]','Interpreter','latex'),ylabel('$y$','Interpreter','latex'),grid
subplot(212),plot(T,U*180/pi),title('$u$: Rudder deflection [deg]','Interpreter','latex'),grid,ylabel('$u$','Interpreter','latex'),xlabel('Time, $t$ [s]','Interpreter','latex')

