% ode45solver.m                                     %
%---------------------------------------------------%
% Investiagation of different control strategies on %
% a simplified non-linear model for a pipeline-riser% 
% process by Di Meglio.                             %  
%---------------------------------------------------%
% Developed by C.D in Octave.

clear all;
clc
randn('seed',1); 
rand('seed',1);
dt = 0.03; %sampling time [s]
t0 = 0; %starting time
t1 = 15; %ending time [s]
T = (0:dt:t1); %time vector
N = length(T); % no. samples

% input experiment
Uexp=(prbs1(N,1,50)*0.005)-0.1;  

%dv=0.001; dw=0.001; 
dv=0; dw=0; 
% storing matrices
X=zeros(N,6); Y=zeros(N,1); U=zeros(N,1);
R=zeros(N,1);
v=randn(N,6)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
 
% settings for mfdelta pi pid tuning
L=5; J=12; n=5; delta=2.3; zeta=28;
%wc=0.4;
m=2;

for i=1:1
    i
    randn('seed',1); 
    rand('seed',1);v=randn(N,4)*dv; w=randn(N,1)*dw;  %No noise, gives perfekt ID model
    vu=0;bprbs=1;
    x=zeros(6,1); x(1)=2; y_old=0;
    z=0; r=5; u=0.;
for k = 1:N
    k
    tk = T(k);
    y=12.901*x(1)^2*x(2)^3-20.659*x(1)^2*abs(x(2))*x(2)-6.471*x(1)^2*(2-x(1)/3)*x(2)-1.297*x(1)^2*x(5)+cos(x(3)+x(2));
    if(bprbs==0)
        if k<900
            u=0.1;
        else
            e=r-y;
            u=Kp*e-KpTdh*(y-y_old)+z;
            z=z+KpTih*e;
        end
	elseif(bprbs==1)
        if k<200
            u=0.1;
        elseif k<600
            u=Uexp(k); 
        else%if k==62200
            Yid=Y(200:end,i); Uid=U(200:end,i);
        if i==2
            [L,J,n,~,V,res]=opt_LJn(Yid,Uid);
            [Kp,Ti,Td]=pidtun(Yid,Uid,dt,m,L,J,n,delta,zeta);
        elseif i==1
            [Kp,Ti,Td]=pidTuner1(Yid,Uid,dt,m);
        end
        KpTdh=Kp*Td/dt;
        KpTih=Kp*dt/Ti; 
        bprbs=0;
        end
    end
    % store last value
    y_old=y; 
    u_old=u;  
	if tk>13
       %u=u+pi/180*45;
       r=1;
    end
    % store data 
    Y(k,i)=y; U(k,i)=u; R(k)=r;
    % discretise the model
    [Time,sol] = ode45(@miss,[tk tk+dt],x',[],u);
    % update model with last element
	x = sol(end,:)'+v(k)';
end
end
figure(1)
plot(T,Y,T,R)
figure(2)
plot(T,U)
% figure(1)
% subplot(211),plot(T,Y(:,1)*180/pi,'r',T,Y(:,2)*180/pi,'b--',T,R*180/pi,'k--'),title('$y$: Angle of attack [deg]','Interpreter','latex'),ylabel('$y$','Interpreter','latex'),grid,t=legend('pidtun','pidTuner1','reference');set(t,'Interpreter','latex');
% subplot(212),plot(T,U(:,1)*180/pi,'r',T,U(:,2)*180/pi,'b--'),title('$u$: Rudder deflection [deg]','Interpreter','latex'),grid,ylabel('$u$','Interpreter','latex'),xlabel('Time, $t$','Interpreter','latex')
% 
% str1 = 'PRBS start';
% text(2.2,30,str1,'Interpreter','latex')
% annotation('arrow','X',[0.207142857142857 0.207142857142857],'Y',[0.403174603174604 0.303174603174604]);
% 
% str2 = 'PRBS stop';
% text(6.2,30,str2,'Interpreter','latex')
% annotation('arrow','X',[0.361904761904761 0.361904761904761],'Y',[0.404761904761906 0.304761904761906]);
% 
% str3 = 'Control on';
% text(9.2,23,str3,'Interpreter','latex')
% annotation('arrow','X',[0.479761904761903 0.479761904761903],'Y',[0.406349206349211 0.306349206349211]);
% 
% a=900; % O step at 0.5 sec
% b=1400; % input step at 3.5 sec
% 
% disp('pidtun')
% IAE_vy_d=trapz(T(a:b), abs(R(a:b)-Y(a:b,1)))
% IAE_vu_d=trapz(T(b:end), abs(R(b:end)-Y(b:end,1)))
% IAE_d=IAE_vy_d+IAE_vu_d
% TV_d=sum(abs(diff(U(a:b,1))))
% TV_d=sum(abs(diff(U(b:end,1))))
% disp('pidtune1')
% IAE_vy_s=trapz(T(a:b), abs(R(a:b)-Y(a:b,2)))
% IAE_vu_s=trapz(T(b:end), abs(R(b:end)-Y(b:end,2)))
% IAE_s=IAE_vy_s+IAE_vu_s
% TV_s=sum(abs(diff(U(a:b,2))))
% TV_d=sum(abs(diff(U(b:end,2))))