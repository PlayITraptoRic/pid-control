function [A,B,D,calL,]=funcc()

end